var class_egg_boom =
[
    [ "EggBoom", "class_egg_boom.html#a2764d0a56611979dd526323d9a6329d4", null ],
    [ "init", "class_egg_boom.html#ac883ecd85441c5d0c641a4bfc477ae2e", null ],
    [ "update", "class_egg_boom.html#a861bdd11c0a6127f85613d812f121771", null ],
    [ "wait_time", "class_egg_boom.html#a88c7dabd08e940c9d5bb7eb741159cac", null ]
];