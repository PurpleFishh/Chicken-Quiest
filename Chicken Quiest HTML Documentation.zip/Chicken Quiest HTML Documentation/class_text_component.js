var class_text_component =
[
    [ "TextComponent", "class_text_component.html#a22b43810786ae5542f2b90177a797abc", null ],
    [ "init", "class_text_component.html#a04674a7d2557f741876f08a468cdce52", null ],
    [ "setText", "class_text_component.html#a423164601f8317cdb5aecf7ae2961626", null ]
];