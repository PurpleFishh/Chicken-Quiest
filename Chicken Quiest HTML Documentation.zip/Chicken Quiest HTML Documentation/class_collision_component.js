var class_collision_component =
[
    [ "CollisionComponent", "class_collision_component.html#ac0af7d4cc89546fa2c7e64a83b22b39f", null ],
    [ "draw", "class_collision_component.html#ab651e0141a8ba3989d4f3be8829c855e", null ],
    [ "getType", "class_collision_component.html#abee44bb257c5c203b9d97a4ae52a17a8", null ],
    [ "init", "class_collision_component.html#ad22b183302cf78202a95c605c1e64505", null ]
];