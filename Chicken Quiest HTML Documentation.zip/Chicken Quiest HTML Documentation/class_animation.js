var class_animation =
[
    [ "Animation", "class_animation.html#a83f0a16cef7117f187ad596de38dd9d6", null ],
    [ "Animation", "class_animation.html#af1af2798467886f34cce9de236a30107", null ],
    [ "setSpeed", "class_animation.html#a0249a16fa506cfa9287f628715de5b63", null ],
    [ "frames", "class_animation.html#a203b48ef06404b46253bd9bb0a6415e9", null ],
    [ "row", "class_animation.html#a71d248a2a6d8c42996513a22052124d7", null ],
    [ "speed", "class_animation.html#a6acc16cb5f403416dbc653098f31e9b3", null ]
];