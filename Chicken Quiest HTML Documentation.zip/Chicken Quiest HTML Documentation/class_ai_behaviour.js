var class_ai_behaviour =
[
    [ "AiBehaviour", "class_ai_behaviour.html#a7ca91d5259d5b2f609c8ea9cd52d09ab", null ],
    [ "init", "class_ai_behaviour.html#afc8a8a1d83f40dbb07d388159eb5a480", null ],
    [ "update", "class_ai_behaviour.html#a89d61de73d05b7eb5213eb03351e11dc", null ]
];