var searchData=
[
  ['ttf_5fdirection_0',['TTF_Direction',['../_s_d_l__ttf_8h.html#a1520f18272c8f9ce64830fcd288e6a46',1,'SDL_ttf.h']]]
];
