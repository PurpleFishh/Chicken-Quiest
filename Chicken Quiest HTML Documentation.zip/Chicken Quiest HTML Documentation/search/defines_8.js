var searchData=
[
  ['player_5fh_0',['PLAYER_H',['../settings_8h.html#aa3fab1fddd7bdec7c2d0867fb8aaad64',1,'settings.h']]],
  ['player_5fw_1',['PLAYER_W',['../settings_8h.html#a019422f3b3e81e20b425884f357f6948',1,'settings.h']]]
];
