var searchData=
[
  ['fps_0',['fps',['../settings_8h.html#af0c7864c138c3ffcc98c0d7ffb3a1482',1,'settings.h']]]
];
