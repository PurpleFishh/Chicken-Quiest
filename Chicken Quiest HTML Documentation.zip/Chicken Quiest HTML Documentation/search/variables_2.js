var searchData=
[
  ['delta_5ftime_0',['delta_time',['../settings_8h.html#a27233e04f3878436a28a54a95209da60',1,'settings.h']]],
  ['destrect_1',['destRect',['../class_sprite_component.html#a67543bef40852ae15e1383afc6682ba4',1,'SpriteComponent']]],
  ['difficulty_2',['difficulty',['../class_map.html#a9a7ceaaeb8b2bd8e1d1e752622878c70',1,'Map']]]
];
