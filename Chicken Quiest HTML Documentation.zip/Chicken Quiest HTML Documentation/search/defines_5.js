var searchData=
[
  ['gravity_5fspeed_0',['gravity_speed',['../settings_8h.html#a08401ce0182a337619fc8f07014aa90f',1,'settings.h']]]
];
