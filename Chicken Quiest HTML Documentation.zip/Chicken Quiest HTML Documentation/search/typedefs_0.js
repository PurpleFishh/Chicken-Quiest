var searchData=
[
  ['ttf_5ffont_0',['TTF_Font',['../_s_d_l__ttf_8h.html#ac3b14e1c2946c0cf19776fe568d9abcf',1,'SDL_ttf.h']]]
];
