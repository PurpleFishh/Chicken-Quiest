var searchData=
[
  ['wait_5ftime_0',['wait_time',['../class_egg_boom.html#a88c7dabd08e940c9d5bb7eb741159cac',1,'EggBoom']]],
  ['width_1',['width',['../class_position_component.html#aeffcef2b9e70740a22c07883df2595a2',1,'PositionComponent']]],
  ['win_5fscreen_5flayers_2',['win_screen_layers',['../class_layers.html#a1e8aa6b739d081e1312efcf774c5a7b2',1,'Layers']]]
];
