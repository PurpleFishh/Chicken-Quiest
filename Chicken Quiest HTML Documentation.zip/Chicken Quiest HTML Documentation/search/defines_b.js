var searchData=
[
  ['unicode_5fbom_5fnative_0',['UNICODE_BOM_NATIVE',['../_s_d_l__ttf_8h.html#a98e376b293c26e85ae636e518fb27822',1,'SDL_ttf.h']]],
  ['unicode_5fbom_5fswapped_1',['UNICODE_BOM_SWAPPED',['../_s_d_l__ttf_8h.html#ad519362832048f87d7050108bac69098',1,'SDL_ttf.h']]]
];
