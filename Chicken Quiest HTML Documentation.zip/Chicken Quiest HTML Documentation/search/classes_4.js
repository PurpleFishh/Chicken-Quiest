var searchData=
[
  ['game_0',['Game',['../class_game.html',1,'']]],
  ['gameinfostorage_1',['GameInfoStorage',['../class_game_info_storage.html',1,'']]]
];
