var searchData=
[
  ['savegameinfofile_0',['saveGameInfoFile',['../settings_8h.html#a5bebd63bdd44c8c1bb50e65bccdbcd5e',1,'settings.h']]],
  ['scenes_5fnum_1',['SCENES_NUM',['../settings_8h.html#a4c932f3366ab43766dca87c875edcf32',1,'settings.h']]],
  ['scr_5fh_2',['SCR_H',['../settings_8h.html#a61b2e5ac0d21f66c13855ee70a1a507d',1,'settings.h']]],
  ['scr_5fw_3',['SCR_W',['../settings_8h.html#a800e692b98ec3f4cc0679e934485ca84',1,'settings.h']]],
  ['sdl_5fdeprecated_4',['SDL_DEPRECATED',['../_s_d_l__ttf_8h.html#ace2a23221522c1222ee165136d2c316c',1,'SDL_ttf.h']]],
  ['sdl_5fttf_5fcompiledversion_5',['SDL_TTF_COMPILEDVERSION',['../_s_d_l__ttf_8h.html#a2ba3940255fc228728d9eb0c5a815aad',1,'SDL_ttf.h']]],
  ['sdl_5fttf_5fmajor_5fversion_6',['SDL_TTF_MAJOR_VERSION',['../_s_d_l__ttf_8h.html#a895f91173346a028d25202ced75b549e',1,'SDL_ttf.h']]],
  ['sdl_5fttf_5fminor_5fversion_7',['SDL_TTF_MINOR_VERSION',['../_s_d_l__ttf_8h.html#ae192fcc5f145ad3ffb3652fe4ab768bb',1,'SDL_ttf.h']]],
  ['sdl_5fttf_5fpatchlevel_8',['SDL_TTF_PATCHLEVEL',['../_s_d_l__ttf_8h.html#a6c438d5ec0bddd2361845ac5d4f7f30b',1,'SDL_ttf.h']]],
  ['sdl_5fttf_5fversion_9',['SDL_TTF_VERSION',['../_s_d_l__ttf_8h.html#ae9baeafdf603e01fdd7f52ef71d7a1e8',1,'SDL_ttf.h']]],
  ['sdl_5fttf_5fversion_5fatleast_10',['SDL_TTF_VERSION_ATLEAST',['../_s_d_l__ttf_8h.html#a96e4c81ae8cdc0cd0df61ec242de01d1',1,'SDL_ttf.h']]]
];
