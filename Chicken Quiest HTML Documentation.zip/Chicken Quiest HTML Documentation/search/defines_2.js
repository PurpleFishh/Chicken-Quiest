var searchData=
[
  ['debug_0',['DEBUG',['../settings_8h.html#ad72dbcf6d0153db1b8d8a58001feed83',1,'settings.h']]]
];
