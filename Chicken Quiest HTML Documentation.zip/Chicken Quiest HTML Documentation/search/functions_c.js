var searchData=
[
  ['removeentity_0',['removeEntity',['../class_layers.html#a48372efb9aef036184b2904ad9d2a727',1,'Layers']]],
  ['render_1',['render',['../class_game.html#a15ddd769261d923827a3cdf41499c843',1,'Game']]],
  ['renderlayers_2',['renderLayers',['../class_layers.html#a5f6bb3b2add5d55906de86ffc95b3b9e',1,'Layers']]]
];
