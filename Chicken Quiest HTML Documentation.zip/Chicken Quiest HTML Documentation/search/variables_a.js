var searchData=
[
  ['menu_5fentities_5fspecialization_0',['menu_entities_specialization',['../class_menu_constructor.html#a3552b32cff9acc079e1044136ab83fca',1,'MenuConstructor']]],
  ['mouse_5fpos_1',['mouse_pos',['../class_game.html#a5aa27f749e70f91c9d45248ad35f8f98',1,'Game']]]
];
