var searchData=
[
  ['layers_5fnum_0',['LAYERS_NUM',['../settings_8h.html#aa4218c20db505c781016feaefe8eb421',1,'settings.h']]],
  ['logo_5fh_1',['LOGO_H',['../settings_8h.html#a533121e92f10ccad32f46afd0214e1e5',1,'settings.h']]],
  ['logo_5fscr_5fh_2',['LOGO_SCR_H',['../settings_8h.html#ad4292c617125ab8f3d98410a725b01f8',1,'settings.h']]],
  ['logo_5fscr_5fw_3',['LOGO_SCR_W',['../settings_8h.html#ad7e441633c291bd53b3d6263d9d6cca6',1,'settings.h']]],
  ['logo_5fw_4',['LOGO_W',['../settings_8h.html#a2bc15932fcdb7b4107c5ba7100205152',1,'settings.h']]],
  ['lvlmapformat_5',['lvlMapFormat',['../settings_8h.html#a99a630324a4fa69130d7c6a01d5df341',1,'settings.h']]],
  ['lvlmaptype_6',['lvlMapType',['../settings_8h.html#ab121edd9f3c87873f2aa17deece2fdf0',1,'settings.h']]]
];
