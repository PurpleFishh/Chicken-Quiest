var searchData=
[
  ['banner_5fh_0',['BANNER_H',['../settings_8h.html#a8ec09aab528dee5167dd1787ace0c5c7',1,'settings.h']]],
  ['banner_5fscr_5fh_1',['BANNER_SCR_H',['../settings_8h.html#a263b41144ed77b84c8f239b4b56f6ee7',1,'settings.h']]],
  ['banner_5fscr_5fw_2',['BANNER_SCR_W',['../settings_8h.html#a687ebf38a3ff85c4687b866f439cca57',1,'settings.h']]],
  ['banner_5fw_3',['BANNER_W',['../settings_8h.html#a5884587a2ddd4b3a431c703a7cf7821a',1,'settings.h']]],
  ['button_5fback_5fh_4',['BUTTON_BACK_H',['../settings_8h.html#a12a42b9e0576dac7a7ac1d371a02c971',1,'settings.h']]],
  ['button_5fback_5fscr_5fh_5',['BUTTON_BACK_SCR_H',['../settings_8h.html#a4a403eec8530c17c32bcc24d47f2ec53',1,'settings.h']]],
  ['button_5fback_5fscr_5fw_6',['BUTTON_BACK_SCR_W',['../settings_8h.html#a2e4509fe31be50f1b07f7f29e8ef24c5',1,'settings.h']]],
  ['button_5fback_5fw_7',['BUTTON_BACK_W',['../settings_8h.html#a767123a508952273a75c96585202477e',1,'settings.h']]],
  ['button_5fh_8',['BUTTON_H',['../settings_8h.html#ae2c42977e6e31dcbd1688b6cc65373d6',1,'settings.h']]],
  ['button_5fscr_5fh_9',['BUTTON_SCR_H',['../settings_8h.html#aceabfe906d58729a50660c8f05620e9d',1,'settings.h']]],
  ['button_5fscr_5fw_10',['BUTTON_SCR_W',['../settings_8h.html#a16fcd752b853839df97b620b39385ddb',1,'settings.h']]],
  ['button_5fw_11',['BUTTON_W',['../settings_8h.html#a5f75244d34bae3edbb472eb2b0fc8e13',1,'settings.h']]]
];
