var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwxy~",
  1: "acdegiklmpstv",
  2: "acdegiklmpstv",
  3: "acdeghilmnoprstuv~",
  4: "acdefghiklmoprstvwxy",
  5: "t",
  6: "glmpstw",
  7: "lst",
  8: "o",
  9: "abdefglmpstu",
  10: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Pages"
};

