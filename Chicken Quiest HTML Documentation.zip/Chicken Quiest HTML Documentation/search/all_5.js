var searchData=
[
  ['fps_0',['fps',['../settings_8h.html#af0c7864c138c3ffcc98c0d7ffb3a1482',1,'settings.h']]],
  ['frames_1',['frames',['../class_sprite_component.html#a2bd9366ad8a5248fc34a7272bef8f8ef',1,'SpriteComponent::frames()'],['../class_animation.html#a203b48ef06404b46253bd9bb0a6415e9',1,'Animation::frames()']]]
];
