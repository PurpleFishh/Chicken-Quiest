var searchData=
[
  ['frames_0',['frames',['../class_sprite_component.html#a2bd9366ad8a5248fc34a7272bef8f8ef',1,'SpriteComponent::frames()'],['../class_animation.html#a203b48ef06404b46253bd9bb0a6415e9',1,'Animation::frames()']]]
];
