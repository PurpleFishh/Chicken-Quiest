var searchData=
[
  ['game_5flayers_0',['game_layers',['../class_layers.html#a91640d827ed1f842e733decc1164f05d',1,'Layers']]],
  ['gameover_5fscreen_5flayers_1',['gameover_screen_layers',['../class_layers.html#a0dcf9132fb89e4ab809b819bc0d117ef',1,'Layers']]]
];
