var class_error_handler =
[
    [ "ErrorHandler", "class_error_handler.html#adcf9250554a72c2141499e572eeeebbd", null ],
    [ "ErrorHandler", "class_error_handler.html#ad9e0d6be852a5ce51385e938b1eca7ce", null ]
];