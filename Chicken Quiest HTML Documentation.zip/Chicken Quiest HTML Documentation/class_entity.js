var class_entity =
[
    [ "~Entity", "class_entity.html#adf6d3f7cb1b2ba029b6b048a395cc8ae", null ],
    [ "addCompoent", "class_entity.html#a537801f90d071dda5f4ab190bbdcb5bf", null ],
    [ "destroy", "class_entity.html#a691dbe5f9ec930c27af2af0b97907a9e", null ],
    [ "draw", "class_entity.html#a7666f416dd0d1fce0f1133f78df44476", null ],
    [ "getComponent", "class_entity.html#ad489ee0d44f9c35d1a61d3a726c5923c", null ],
    [ "getLayer_Id", "class_entity.html#a29dbdf8ac32620b37cf33b7f1f9c2e0a", null ],
    [ "handleEvents", "class_entity.html#a982a2deb17a9f3ef1f6ecd40c33c8017", null ],
    [ "hasComponent", "class_entity.html#ad42785721cb226a1bea8025aeb1d9e8d", null ],
    [ "isActive", "class_entity.html#a00a0f5a9e9f39be9b9db28d5dbccd20e", null ],
    [ "setLayer_Id", "class_entity.html#a6c7e68567b3ad4775872f92e07807096", null ],
    [ "update", "class_entity.html#a00b6eeaf99b35c8f8b10b5fbfc1baf4f", null ]
];