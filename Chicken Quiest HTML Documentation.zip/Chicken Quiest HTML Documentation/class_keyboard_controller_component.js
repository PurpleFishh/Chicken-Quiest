var class_keyboard_controller_component =
[
    [ "handleEvents", "class_keyboard_controller_component.html#a2638ecfcea577d93ba2f53bab03de703", null ],
    [ "init", "class_keyboard_controller_component.html#aa956fc803a03646719da59cf4db6368a", null ],
    [ "able_to_move", "class_keyboard_controller_component.html#a7b6cf9d1a89309ee38bf3593da131d60", null ]
];