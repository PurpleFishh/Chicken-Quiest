var class_game =
[
    [ "Game", "class_game.html#ad59df6562a58a614fda24622d3715b65", null ],
    [ "~Game", "class_game.html#ae3d112ca6e0e55150d2fdbc704474530", null ],
    [ "getRunning", "class_game.html#ae0e7ead5d12f08461cd9e998366bfb1e", null ],
    [ "handleEvents", "class_game.html#adb5563f62c0c82e3e42ec36501aa5698", null ],
    [ "init", "class_game.html#a6fb6ab188f447a0b1448f77426a2ad79", null ],
    [ "render", "class_game.html#a15ddd769261d923827a3cdf41499c843", null ],
    [ "update", "class_game.html#a79df6376b332d63c9eca0dcee30305c3", null ]
];