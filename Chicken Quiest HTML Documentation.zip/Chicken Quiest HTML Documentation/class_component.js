var class_component =
[
    [ "~Component", "class_component.html#a2e9aa4348314d981f05f67397ad2f872", null ],
    [ "draw", "class_component.html#a2fc563e2f7e0c20902fc4f9d5e69e02a", null ],
    [ "handleEvents", "class_component.html#a5a6a653c91fd1326efc0a15020c25dc6", null ],
    [ "init", "class_component.html#a162f8cdc070537a71f2ad0b5e763b86f", null ],
    [ "update", "class_component.html#a2c9d95ea989f2d69381ad9b6728b51ae", null ],
    [ "entity", "class_component.html#a6acb3f00c9d114d961c8763ede390d2c", null ]
];